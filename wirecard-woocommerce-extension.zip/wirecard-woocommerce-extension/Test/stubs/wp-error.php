<?php

class WP_Error {

}
